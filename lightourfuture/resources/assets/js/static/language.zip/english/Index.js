export default{   
  
    "userTypes" : {
        "company"   : "company",
        "student"   : "student",
        "professor" : "professor",
        "agent"     : "agent"
    },

    "welcomeMessage" : {
        "company"   : "welcome Company",
        "student"   : "welcome Student",
        "professor" : "welcome Professor",
        "agent"     : "welcome Agent"
    },

    "loginMessage" : {
        "signIn"        : "Sign In",
        "signUs"        : "Sign Us",
        "findAccount"   : "Find Account"
    },
    
    "findAccountMessage" : {
        "name"  : "Name",
        "email" : "Email",
        "id"    : "ID",
        "find"  : "Find"
    }

}
