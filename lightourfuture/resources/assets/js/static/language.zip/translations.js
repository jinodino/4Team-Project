import en from "./english/Index.js"
import kr from "./korean/Index.js"
import ja from "./japanese/Index.js"

export default {
    en ,
    ja ,
    kr 
};

