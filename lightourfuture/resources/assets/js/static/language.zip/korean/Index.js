export default{   

    "userTypes" : {
        "company"   : "기업",
        "student"   : "학생",
        "professor" : "교수",
        "agent"     : "에이전트"
    },

    "welcomeMessage" : {
        "company"   : "안녕하세요 기업",
        "student"   : "안녕하세요 학생",
        "professor" : "안녕하세요 교수님",
        "agent"     : "안녕하세요 에이전트"
    },

    "loginMessage" : {
        "signIn"        : "로그인",
        "signUs"        : "회원가입",
        "findAccount"   : "ID・비밀번호 찾기"
    },

    "findAccountMessage" : {
        "name"  : "이름",
        "email" : "Email",
        "id"    : "ID",
        "find"  : "찾기"
    },
    
    "studentNavi" : {
        "mypage" : "MyPage"
    }

}