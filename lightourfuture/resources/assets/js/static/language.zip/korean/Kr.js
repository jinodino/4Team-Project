import Index from "./Index.js";     //Index page

export default{
    Index 
}