import Index from "./Index.js";

export default{
    Index
}