export default{   
        
    "userTypes" : {
        "company"   : "企業",
        "student"   : "学生",
        "professor" : "先生",
        "agent"     : "エージェント"
    },

    "welcomeMessage" : {
        "company"   : "こんにちは　企業",
        "student"   : "こんにちは　学生",
        "professor" : "こんにちは　先生",
        "agent"     : "こんにちは　エージェントさ"
    },
    
    "loginMessage" : {
        "signIn"        : "ログイン",
        "signUs"        : "会員登録",
        "findAccount"   : "会員ID・パスワード問い合わせ"
    },
    
    "findAccountMessage" : {
        "name"  : "名前",
        "email" : "メールアドレス",
        "id"    : "会員ID",
        "find"  : "問い合わせ"
    }

}